﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=localhost\\SQLEXPRESS05;Database=BookShop;Trusted_Connection=True";

    }
}
