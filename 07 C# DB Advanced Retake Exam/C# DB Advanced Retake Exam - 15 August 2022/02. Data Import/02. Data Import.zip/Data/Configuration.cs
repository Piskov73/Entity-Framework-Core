﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost\SQLEXPRESS05;Database=Trucks;Trusted_Connection=True";
    }
}