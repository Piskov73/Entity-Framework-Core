﻿namespace VaporStore.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=localhost\SQLEXPRESS05;Database=VaporStore;Integrated Security=True;Encrypt=False";
    }
}