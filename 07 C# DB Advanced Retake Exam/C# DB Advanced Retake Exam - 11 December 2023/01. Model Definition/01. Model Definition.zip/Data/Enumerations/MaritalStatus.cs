﻿namespace Cadastre.Data.Enumerations
{
    public enum  MaritalStatus
    {
        Unmarried = 0,
        Married,
        Divorced,
        Widowed
    }
}
