﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string
            ConnectionString = @"Server=localhost\SQLEXPRESS05;Database=Cadastre;Trusted_Connection=True;";
    }
}
