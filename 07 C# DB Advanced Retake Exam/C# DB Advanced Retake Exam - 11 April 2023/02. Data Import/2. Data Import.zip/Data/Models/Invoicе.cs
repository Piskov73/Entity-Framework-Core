﻿namespace Invoices.Data.Models
{
    public class Invoicе
    {
    }
}