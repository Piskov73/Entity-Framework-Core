﻿namespace Invoices.Data.Models.Enums
{
    public enum CategoryType
    {
        ADR = 0,
        Filters,
        Lights,
        Others,
        Tyres
    }
}
