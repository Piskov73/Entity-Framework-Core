﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost\SQLEXPRESS05;Database=Artillery;Integrated Security=True;Encrypt=False";
    }
}
