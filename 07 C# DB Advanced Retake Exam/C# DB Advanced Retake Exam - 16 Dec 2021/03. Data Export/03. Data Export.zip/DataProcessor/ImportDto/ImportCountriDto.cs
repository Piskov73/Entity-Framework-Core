﻿namespace Artillery.DataProcessor.ImportDto
{
    public class ImportCountriDto
    {
        public int Id { get; set; } 
    }
}