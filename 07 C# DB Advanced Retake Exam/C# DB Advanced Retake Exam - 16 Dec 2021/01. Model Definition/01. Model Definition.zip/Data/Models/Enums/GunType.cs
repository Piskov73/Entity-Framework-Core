﻿namespace Artillery.Data.Models.Enums
{
    public enum GunType
    {
        Howitzer = 0,
        Mortar,
        FieldGun,
        AntiAircraftGun,
        MountainGun,
        AntiTankGun
    }
}
