﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=localhost\SQLEXPRESS05;Database=Medicines;Trusted_Connection=True;";
    }
}
