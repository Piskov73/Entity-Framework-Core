﻿namespace SoftJail.Data.Models.Enums
{
    public  enum Weapon
    {
        Knife=0,
        FlashPulse, 
        ChainRifle, 
        Pistol, 
        Sniper
    }
}
