﻿namespace SoftJail.Data.Models.Enums
{
    public enum Position
    {
        Overseer=0, 
        Guard,
        Watcher,
        Labour
    }
}
