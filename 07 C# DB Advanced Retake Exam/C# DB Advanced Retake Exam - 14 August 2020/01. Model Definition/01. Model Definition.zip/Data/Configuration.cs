﻿namespace SoftJail.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost\SQLEXPRESS05;Database=SoftJail;Integrated Security=True;Encrypt=False;";
    }
}
