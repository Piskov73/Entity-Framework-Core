﻿namespace Theatre.DataProcessor.ExportDto
{
    public class ExportTicketsDto
    {

        //"Price": 93.48,
        public decimal Price { get; set; }

        //"RowNumber": 3
        public sbyte RowNumber { get; set; }

    }
}