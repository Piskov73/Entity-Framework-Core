﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost\SQLEXPRESS05;Database=Theatre;Integrated Security=True;Encrypt=False";
    }
}
