﻿namespace Boardgames.Data.Models.Enums
{
    public enum CategoryType
    {
        Abstract = 0,
        Children,
        Family,
        Party,
        Strategy
    }
}
