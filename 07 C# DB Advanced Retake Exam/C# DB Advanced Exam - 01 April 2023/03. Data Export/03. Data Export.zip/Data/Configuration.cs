﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost\SQLEXPRESS05;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
