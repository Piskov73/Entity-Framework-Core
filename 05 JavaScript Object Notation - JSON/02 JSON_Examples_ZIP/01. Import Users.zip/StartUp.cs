﻿using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            ProductShopContext context = new ProductShopContext();

            //1#
            string inputUsers = File.ReadAllText("../../../Datasets/users.json");
            Console.WriteLine(ImportUsers(context,inputUsers));


        }
        //1
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            var users=JsonConvert.DeserializeObject<List<User>>(inputJson);
            context.Users.AddRange(users);
            context.SaveChanges();
            return $"Successfully imported {users.Count}";
        }
    }
}