﻿using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using Castle.Core.Resource;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            CarDealerContext context = new CarDealerContext();


            //9#
            //string inputSuppliers = File.ReadAllText("../../../Datasets/suppliers.json");
            //Console.WriteLine(ImportSuppliers(context, inputSuppliers));

            //10#
            //string inputParts = File.ReadAllText("../../../Datasets/parts.json");
            //Console.WriteLine(ImportParts(context, inputParts));

            //11#
            //string inputCarsJson = File.ReadAllText("../../../Datasets/cars.json");
            //Console.WriteLine(ImportCars(context, inputCarsJson));

            //12# 
            string inputCustomers = File.ReadAllText("../../../Datasets/customers.json");
            Console.WriteLine(ImportCustomers(context, inputCustomers));

        }
        //9#
        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            var suppliers = JsonConvert.DeserializeObject<List<Supplier>>(inputJson);

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}.";
        }

        //10#
        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            var parts = JsonConvert.DeserializeObject<List<Part>>(inputJson);
            var existingSupplierIds = context.Suppliers.Select(s => s.Id).ToList();
            var partsSupplierIdNottNull = parts
                .Where(p => p.SupplierId != null && existingSupplierIds
                .Contains(p.SupplierId)).ToList();

            context.Parts.AddRange(partsSupplierIdNottNull);
            context.SaveChanges();

            return $"Successfully imported {partsSupplierIdNottNull.Count}.";
        }
        //11#
        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            var carsDTO = JsonConvert.DeserializeObject<List<CarDTO>>(inputJson);
            var cars = new HashSet<Car>();
            var partCars = new HashSet<PartCar>();

            foreach (var carDto in carsDTO)
            {
                var car = new Car();

                car.Make = carDto.Make;
                car.Model = carDto.Model;
                car.TraveledDistance = carDto.TraveledDistance;
                cars.Add(car);

                foreach (var partId in carDto.PartsId)
                {
                    var partCar = new PartCar();
                    partCar.Car = car;
                    partCar.PartId = partId;
                    partCars.Add(partCar);
                }
            }

            context.Cars.AddRange(cars);
            context.PartsCars.AddRange(partCars);
            context.SaveChanges();
            return $"Successfully imported {cars.Count}.";
        }
        //12#
        public static string ImportCustomers(CarDealerContext context, string inputJson)
        {
            var customers = JsonConvert.DeserializeObject<HashSet<Customer>>(inputJson);
            context.Customers.AddRange(customers);
            context.SaveChanges();
            return $"Successfully imported {customers.Count}.";
        }

    }
}