﻿using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            ProductShopContext context = new ProductShopContext();

            //1#
            //string inputUsers = File.ReadAllText("../../../Datasets/users.json");
            //Console.WriteLine(ImportUsers(context, inputUsers));

            //2#
            //string inputProducts = File.ReadAllText("../../../Datasets/products.json");
            //Console.WriteLine(ImportProducts(context, inputProducts));

            //3#
            string inputCategories = File.ReadAllText("../../../Datasets/categories.json");
            Console.WriteLine(ImportCategories(context,inputCategories));

        }
        //1
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            var users=JsonConvert.DeserializeObject<List<User>>(inputJson);
            context.Users.AddRange(users);
            context.SaveChanges();
            return $"Successfully imported {users.Count}";
        }

        //2#
        public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            var products=JsonConvert.DeserializeObject<List<Product>>(inputJson);
            context.Products.AddRange(products);
            context.SaveChanges();
            return $"Successfully imported {products.Count}";
        }

        //3#
        public static string ImportCategories(ProductShopContext context, string inputJson)
        {
            var categories=JsonConvert.DeserializeObject<List<Category>>(inputJson);
            var categoriesNameNotNull = categories.Where(c=>c.Name!=null).ToList();
            context.Categories.AddRange(categoriesNameNotNull);
            context.SaveChanges();
            return $"Successfully imported {categoriesNameNotNull.Count}";
        }
    }
}