﻿namespace P02_FootballBetting.Data.Models.Enums
{
    public enum  Prediction
    {
        Drae=0,
        Win=1,
        Lose=2
    }
}
