﻿using ProductShop.Data;
using ProductShop.DTOs.Import;
using ProductShop.Models;
using System.Xml.Serialization;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            using ProductShopContext context = new ProductShopContext();

            //1#
            string inputuser = File.ReadAllText("../../../Datasets/users.xml");
            Console.WriteLine(ImportUsers(context, inputuser));

        }

        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(UserImportDTO[]), new XmlRootAttribute("Users"));
            UserImportDTO[] userImports;
            using (var reader =new StringReader(inputXml))
            {
                userImports = (UserImportDTO[])xmlSerializer.Deserialize(reader);
            };

            var users = userImports.Select(u => new User
            {
                FirstName=u.FirstName,
                LastName=u.LastName,
                Age=u.Age,
            }).ToArray();

            context.Users.AddRange(users);
            context.SaveChanges();
            return $"Successfully imported {users.Length}";
        }
    }
}