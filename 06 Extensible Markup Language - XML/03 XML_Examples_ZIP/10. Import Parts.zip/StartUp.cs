﻿using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using var context = new CarDealerContext();
            //9#
            //string inputSuppliers = File.ReadAllText("../../../Datasets/suppliers.xml");
            //Console.WriteLine(ImportSuppliers(context, inputSuppliers));

            //10#
            string inputParts = File.ReadAllText("../../../Datasets/parts.xml");
            Console.WriteLine(ImportParts(context, inputParts));
        }

        //9#
        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(SupplierImportDTO[])
                , new XmlRootAttribute("Suppliers"));

            SupplierImportDTO[]? suppliersDTO;

            using var reder = new StringReader(inputXml);

            suppliersDTO = xmlSerializer.Deserialize(reder) as SupplierImportDTO[];

            var suppliers = suppliersDTO?.Select(s => new Supplier
            {
                Name = s.Name,
                IsImporter = s.IsImporter
            }).ToList();

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();
            return $"Successfully imported {suppliers?.Count}";
        }

        //10#

        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(PartImortDTO[]), new XmlRootAttribute("Parts"));

            PartImortDTO[]? partsDTO;

            using var reader = new StringReader(inputXml);

            partsDTO = serializer.Deserialize(reader) as PartImortDTO[];

            var validSupplierId = context.Suppliers.Select(s => s.Id).ToList();

            var parts = partsDTO?.Where(p => validSupplierId.Contains(p.SupplierId))
                .Select(p=> new Part
                {
                    Name=p.Name,
                    Price=p.Price,
                    Quantity=p.Quantity,
                    SupplierId=p.SupplierId
                })
                .ToList();
            context.Parts.AddRange(parts);
            context.SaveChanges();
            return $"Successfully imported {parts.Count}";
        }
    }
}