﻿using ProductShop.Data;
using ProductShop.DTOs.Import;
using ProductShop.Models;
using System.Xml.Serialization;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            using ProductShopContext context = new ProductShopContext();

            //1#
            //string inputuser = File.ReadAllText("../../../Datasets/users.xml");
            //Console.WriteLine(ImportUsers(context, inputuser));

            //2#
            //string inputProducts = File.ReadAllText("../../../Datasets/products.xml");
            //Console.WriteLine(ImportProducts(context, inputProducts));

            //3#
            //string inpueCategories = File.ReadAllText("../../../Datasets/categories.xml");
            //Console.WriteLine(ImportCategories(context, inpueCategories));

        }
        //1#
        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(UserImportDTO[]), new XmlRootAttribute("Users"));
            UserImportDTO[] userImports;
            using (var reader = new StringReader(inputXml))
            {
                userImports = (UserImportDTO[])xmlSerializer.Deserialize(reader);
            };

            var users = userImports.Select(u => new User
            {
                FirstName = u.FirstName,
                LastName = u.LastName,
                Age = u.Age,
            }).ToArray();

            context.Users.AddRange(users);
            context.SaveChanges();
            return $"Successfully imported {users.Length}";
        }
        //2#
        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ProductImportDTO[]), new XmlRootAttribute("Products"));
            ProductImportDTO[] productImports;
            using (var reader = new StringReader(inputXml))
            {
                productImports = (ProductImportDTO[])xmlSerializer.Deserialize(reader);
            }

            var products = productImports
                .Select(p => new Product
                {
                    Name = p.Name,
                    Price = p.Price,
                    SellerId = p.SellerId,
                    BuyerId = p.BuyerId == 0 ? (int?)null : p.BuyerId
                }).ToArray();
            context.Products.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Length}";
        }
        //3#
        public static string ImportCategories(ProductShopContext context, string inputXml)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<CategoryImportDTO>)
                , new XmlRootAttribute("Categories"));
            List<CategoryImportDTO> categoriesImport;
            using(var reader=new StringReader(inputXml))
            {
                 categoriesImport = (List<CategoryImportDTO>)xmlSerializer.Deserialize(reader);
            }

            var categories = categoriesImport.Where(c => c.Name != null)
                .Select(c => new Category
                {
                    Name=c.Name
                }).ToList();
            context.Categories.AddRange(categories);
            context.SaveChanges();
            return $"Successfully imported {categories.Count}";
        }
    }
}