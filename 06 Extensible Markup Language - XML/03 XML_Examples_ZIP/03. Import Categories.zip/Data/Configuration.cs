﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=localhost\SQLEXPRESS05;Database=ProductShop;Integrated Security=True;Encrypt=False";
    }
}
