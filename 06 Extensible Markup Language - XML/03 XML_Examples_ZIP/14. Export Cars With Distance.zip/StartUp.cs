﻿using CarDealer.Data;
using CarDealer.DTOs.Export;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using System.Text;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using var context = new CarDealerContext();
            ////9#
            //string inputSuppliers = File.ReadAllText("../../../Datasets/suppliers.xml");
            //Console.WriteLine(ImportSuppliers(context, inputSuppliers));

            ////10#
            //string inputParts = File.ReadAllText("../../../Datasets/parts.xml");
            //Console.WriteLine(ImportParts(context, inputParts));

            ////11#
            //string inputCars = File.ReadAllText("../../../Datasets/cars.xml");
            //Console.WriteLine(ImportCars(context, inputCars));

            //    //12#
            //    string inputCustomers = File.ReadAllText("../../../Datasets/customers.xml");
            //    Console.WriteLine(ImportCustomers(context,inputCustomers));

            ////13#
            //string inputSales = File.ReadAllText("../../../Datasets/sales.xml");
            //Console.WriteLine(ImportSales(context, inputSales));

            //14#
            Console.WriteLine(GetCarsWithDistance(context));

        }

        //9#
        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(SupplierImportDTO[])
                , new XmlRootAttribute("Suppliers"));

            SupplierImportDTO[]? suppliersDTO;

            using var reder = new StringReader(inputXml);

            suppliersDTO = xmlSerializer.Deserialize(reder) as SupplierImportDTO[];

            var suppliers = suppliersDTO?.Select(s => new Supplier
            {
                Name = s.Name,
                IsImporter = s.IsImporter
            }).ToList();

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();
            return $"Successfully imported {suppliers?.Count}";
        }

        //10#

        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(PartImortDTO[]), new XmlRootAttribute("Parts"));

            PartImortDTO[]? partsDTO;

            using var reader = new StringReader(inputXml);

            partsDTO = serializer.Deserialize(reader) as PartImortDTO[];

            var validSupplierId = context.Suppliers.Select(s => s.Id).ToList();

            var parts = partsDTO?.Where(p => validSupplierId.Contains(p.SupplierId))
                .Select(p => new Part
                {
                    Name = p.Name,
                    Price = p.Price,
                    Quantity = p.Quantity,
                    SupplierId = p.SupplierId
                })
                .ToList();
            context.Parts.AddRange(parts);
            context.SaveChanges();
            return $"Successfully imported {parts.Count}";
        }

        //11#
        public static string ImportCars(CarDealerContext context, string inputXml)
        {
            var serializer = new XmlSerializer(typeof(List<CarImportDTO>), new XmlRootAttribute("Cars"));

            List<CarImportDTO>? carsDTO;

            using StringReader reader = new StringReader(inputXml);
            carsDTO = serializer.Deserialize(reader) as List<CarImportDTO>;

            List<Car> cars = new List<Car>();

            List<PartCar> partsCars = new List<PartCar>();

            List<int> validPartsId = context.Parts.Select(p => p.Id).ToList();

            foreach (var carDTO in carsDTO)
            {
                Car car = new Car()
                {
                    Make = carDTO.Make,
                    Model = carDTO.Model,
                    TraveledDistance = carDTO.TraveledDistance
                };
                cars.Add(car);

                foreach (var part in carDTO.Parts.Select(p => p.Id).Where(id => validPartsId.Contains(id)).Distinct())
                {
                    PartCar partCar = new PartCar()
                    {
                        PartId = part,
                        Car = car
                    };
                    partsCars.Add(partCar);
                }
            }

            context.Cars.AddRange(cars);
            context.PartsCars.AddRange(partsCars);

            context.SaveChanges();

            return $"Successfully imported {cars.Count}";
        }

        //12#
        public static string ImportCustomers(CarDealerContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<CustomerImportDTO>), new XmlRootAttribute("Customers"));
            List<CustomerImportDTO>? customersDTO;
            using StringReader reader = new StringReader(inputXml);
            customersDTO = serializer.Deserialize(reader) as List<CustomerImportDTO>;
            var customers = customersDTO.Select(c => new Customer
            {
                Name = c.Name,
                BirthDate = c.BirthDate,
                IsYoungDriver = c.IsYoungDriver
            }).ToList();

            context.Customers.AddRange(customers);
            context.SaveChanges();

            return $"Successfully imported {customers.Count}";
        }

        //13#
        public static string ImportSales(CarDealerContext context, string inputXml)
        {
            var serilaizer = new XmlSerializer(typeof(List<SaleImportDTO>), new XmlRootAttribute("Sales"));

            List<SaleImportDTO>? salesDTO;
            using var reade = new StringReader(inputXml);
            salesDTO = serilaizer.Deserialize(reade) as List<SaleImportDTO>;

            List<int> validCarID = context.Cars.Select(c => c.Id).ToList();
            List<int> validCustomerId = context.Customers.Select(c => c.Id).ToList();

            List<Sale> sales = salesDTO
                .Where(s => validCarID.Contains(s.CarId))
                .Select(s => new Sale
                {
                    CarId = s.CarId,
                    CustomerId = s.CustomerId,
                    Discount = s.Discount
                }).ToList();
            context.Sales.AddRange(sales);
            context.SaveChanges();
            return $"Successfully imported {sales.Count}";
        }

        //14
        public static string GetCarsWithDistance(CarDealerContext context)
        {
            var carsWithDistance = context.Cars.Where(c => c.TraveledDistance > 2000000)
                .OrderBy(c => c.Make).ThenBy(c => c.Model)
                .Select(c => new CarExportDTO
                {
                    Make = c.Make,
                    Model = c.Model,
                    TraveledDistance = c.TraveledDistance,
                }).Take(10).ToList();

            XmlSerializer serializer=new XmlSerializer(typeof(List<CarExportDTO>),new XmlRootAttribute("cars"));

            XmlSerializerNamespaces xmlns = new XmlSerializerNamespaces();
            xmlns.Add("", "");

            StringBuilder sb=new StringBuilder();

            using StringWriter writer=new StringWriter(sb);

            serializer.Serialize(writer, carsWithDistance,xmlns);
            return sb.ToString().TrimEnd();
        }

    }
}