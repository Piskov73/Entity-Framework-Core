﻿using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using var context = new CarDealerContext();
            //9#
            string inputSuppliers = File.ReadAllText("../../../Datasets/suppliers.xml");
            Console.WriteLine(ImportSuppliers(context, inputSuppliers));
        }

        //9#
        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(SupplierImportDTO[])
                , new XmlRootAttribute("Suppliers"));

            SupplierImportDTO[]? suppliersDTO;

            using var reder = new StringReader(inputXml);

            suppliersDTO = xmlSerializer.Deserialize(reder) as SupplierImportDTO[];

            var suppliers = suppliersDTO?.Select(s => new Supplier
            {
                Name = s.Name,
                IsImporter = s.IsImporter
            }).ToList();

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();
            return $"Successfully imported {suppliers?.Count}";
        }
    }
}